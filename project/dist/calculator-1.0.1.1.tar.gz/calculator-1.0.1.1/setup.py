# -*- coding: utf-8 -*-
"""
Created on Sun Aug 28 16:16:18 2022

@author: reddy.chandra
"""

from setuptools import setup

setup(
      name= "calculator",
      version='1.0.1.1',
      author='tharun',
      author_email='reddy.chandra@mphasis.com',
      url='mphasis.com',
      py_modules=['calulator'],
)      
      
    
      
      
      
      