# -*- coding: utf-8 -*-
"""
Created on Sun Aug 28 10:02:17 2022

@author: reddy.chandra
"""

def add(x,y):
    
    return x+y
def sub(x,y):
    return x-y
def multiply(x,y):
    return x*y
